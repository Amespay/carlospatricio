<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

?>				
				</main>
			</div>
			<?php
			if ( RDTheme::$layout == 'right-sidebar' ) {
				get_sidebar();
			}
			?>
		</div><!-- .row -->
	</div><!-- container -->
</div><!-- #primary -->