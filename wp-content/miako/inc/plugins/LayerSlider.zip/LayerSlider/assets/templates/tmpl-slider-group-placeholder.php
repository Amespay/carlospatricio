<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-slider-group-placeholder">
<div class="item scale0">
	<div class="preview">
		<div class="no-preview">
			<?php _e('No Preview', 'LayerSlider') ?>
		</div>
	</div>
</div>
</script>